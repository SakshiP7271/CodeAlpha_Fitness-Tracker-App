document.getElementById('workout-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const workoutType = document.getElementById('workout-type').value;
    const duration = document.getElementById('duration').value;
    addProgress(`Workout: ${workoutType} for ${duration} minutes`);
});

document.getElementById('goal-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const goalType = document.getElementById('goal-type').value;
    const target = document.getElementById('target').value;
    addProgress(`Goal Set: ${goalType} - ${target}`);
});

function addProgress(text) {
    const li = document.createElement('li');
    li.textContent = text;
    document.getElementById('progress-list').appendChild(li);
}
